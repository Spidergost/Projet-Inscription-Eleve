﻿<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
		<link rel="stylesheet" type="text/css" href="css/affichage-stagiaires.css" media="screen" />
        <title>Liste des stagiaires</title>
    </head>

    <body>
	<div class="titre">
    	<h1>Liste des stagiaires : </h1>
	</div>
		
	<div class="tableau">
		<?php include('req-affichage-stagiaires.php'); ?>
	</div>
	
        </br>
		<a href="index.php">Retour au menu</a>

	</body>
</html>